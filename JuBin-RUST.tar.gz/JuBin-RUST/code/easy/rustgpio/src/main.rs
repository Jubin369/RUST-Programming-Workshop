extern crate byteorder;

use byteorder::{LittleEndian, WriteBytesExt, ReadBytesExt};
use std::env;
use std::net::TcpStream;
use std::io::{Read, Write, Cursor};
use std::time::Duration;
use std::thread;
use std::sync::{Arc,Mutex};

type CallbackFn = fn(u32, u32, u32);

fn to_bytevector(a: u32, b: u32, 
                c: u32, d: u32) -> Vec<u8> {
    let mut v = vec![];

    v.write_u32::<LittleEndian>(a).unwrap();
    v.write_u32::<LittleEndian>(b).unwrap();
    v.write_u32::<LittleEndian>(c).unwrap();
    v.write_u32::<LittleEndian>(d).unwrap();

    v
}

fn to_bytevector_ext(a: u32, b: u32,
                    c: u32, d: u32, 
                    ext: Vec<Vec<u8>>) -> Vec<u8> {

    let mut v = to_bytevector(a, b, c, d);
        
    for item in &ext {
        v.extend(item);
    }

    v
}

fn unpack_data_in_callback_thread(a: &[u8]) -> 
            (u16, u16, u32, u32) {

    let mut rdr = Cursor::new(a);
    
    (rdr.read_u16::<LittleEndian>().unwrap(),
     rdr.read_u16::<LittleEndian>().unwrap(),
     rdr.read_u32::<LittleEndian>().unwrap(),
     rdr.read_u32::<LittleEndian>().unwrap(),)
}

fn to_i32(r: u32) -> i32 {
    if (r as i32) < 0 {
        panic!("Command not executed successfully");
    }
    r as i32
}

fn to_u32(mut a: &[u8]) -> u32 {
    let r = a.read_u32::<LittleEndian>().
            expect("to_i32: error in packing");
    r
}

struct Pi {
    control_stream: Arc<Mutex<TcpStream>>,
    _notify: Arc<_callback_thread>,
}

#[derive(Clone)]
#[derive(PartialEq)]
struct _callback_ADT {
    gpio: u32,
    edge: u32,
    bit: u32,
    func: CallbackFn,
}

struct _callback_thread {
    callbacks: Mutex<Vec<_callback_ADT>>,
    monitor: Mutex<u32>,
    go: Mutex<bool>,
    control_stream: Arc<Mutex<TcpStream>>,
    notify_stream: Mutex<TcpStream>,
    handle: u32,
}

struct _callback{
    _notify: Arc<_callback_thread>,
    count: u32,          
    _reset: bool,
    callb: _callback_ADT,
}

const INPUT: u32 = 0;
const OUTPUT: u32 = 1;

const PUD_OFF: u32 = 0;
const PUD_DOWN: u32 = 1;
const PUD_UP: u32 = 2;

const _PI_CMD_MODES: u32 = 0;
const _PI_CMD_MODEG: u32 = 1;
const _PI_CMD_PUD: u32 = 2;
const _PI_CMD_READ: u32 = 3;
const _PI_CMD_WRITE: u32 = 4;
const _PI_CMD_PWM: u32 = 5;
const _PI_CMD_SERVO: u32 = 8;

const _PI_CMD_NB: u32 = 19;
const _PI_CMD_NC: u32 = 21;

const _PI_CMD_I2CO: u32 = 54;
const _PI_CMD_I2CC: u32 = 55;
const _PI_CMD_I2CRD: u32 = 56;
const _PI_CMD_I2CWD: u32 = 57;
const _PI_CMD_I2CWQ: u32 = 58;
const _PI_CMD_I2CRS: u32 = 59;
const _PI_CMD_I2CWS: u32 = 60;
const _PI_CMD_I2CRB: u32 = 61;
const _PI_CMD_I2CWB: u32 = 62;
const _PI_CMD_I2CRW: u32 = 63;
const _PI_CMD_I2CWW: u32 = 64;
const _PI_CMD_I2CRK: u32 = 65;
const _PI_CMD_I2CWK: u32 = 66;
const _PI_CMD_I2CRI: u32 = 67;
const _PI_CMD_I2CWI: u32 = 68;
const _PI_CMD_I2CPC: u32 = 69;
const _PI_CMD_I2CPK: u32 = 70;

const _PI_CMD_SPIO: u32 = 71;
const _PI_CMD_SPIC: u32 = 72;
const _PI_CMD_SPIR: u32 = 73;
const _PI_CMD_SPIW: u32 = 74;
const _PI_CMD_SPIX: u32 = 75;

const _PI_CMD_GDC: u32 = 83;
const _PI_CMD_GPW: u32 = 84;

const _PI_CMD_NOIB: u32 = 99;
const _PI_CMD_BR1: u32 = 10;
const NTFY_FLAGS_WDOG: u32 = (1 << 5);
const NTFY_FLAGS_GPIO: u32 = 31;
const TIMEOUT: u32 = 2;

const RISING_EDGE: u32 = 0;
const FALLING_EDGE: u32 = 1;
const EITHER_EDGE: u32 = 2;

impl _callback {
    fn new(notify: Arc<_callback_thread>, 
           user_gpio: u32, edge: u32, 
           func: CallbackFn) -> _callback {

        let callb = _callback_ADT
                    ::new(user_gpio, edge, func);
        
        notify.append(callb.clone());

        _callback {
            _notify: notify, 
            count: 0,
            _reset: false, 
            callb: callb,
        } 
    }

    fn remove(&self) {
        self._notify.remove(&self.callb);
    }
}

impl _callback_ADT {
    fn new(gpio: u32, edge: u32, 
           func: CallbackFn) -> _callback_ADT {

        _callback_ADT {
            gpio: gpio, 
            edge: edge, 
            func: func, 
            bit: (1 << gpio),
        }
    }
}

impl _callback_thread {
    fn new(control_stream: Arc<Mutex<TcpStream>>,
           host: String, port: String) -> Arc<_callback_thread> {
        let serv_addr = format!("{}:{}", host, port);
        let mut notify_stream = TcpStream::connect(&*serv_addr).unwrap();
        let notify_stream = Mutex::new(notify_stream);
        let handle = _pigpio_command(& notify_stream, 
                                     _PI_CMD_NOIB, 0, 0);


        let r = _callback_thread {
                    callbacks: Mutex::new(vec![]),
                    monitor: Mutex::new(0),
                    go: Mutex::new(true),
                    control_stream: control_stream,
                    notify_stream: notify_stream,
                    handle: handle
                };
        
        let r = Arc::new(r);
        let r1 = r.clone();
        thread::spawn(move || notification_thread(r));
    
        r1
        
    }    
    
    fn append(&self, callb: _callback_ADT) {
        *(self.monitor.lock().unwrap()) |= callb.bit;
        _pigpio_command(& self.control_stream, _PI_CMD_NB, 
                        self.handle, *(self.monitor.lock().unwrap()));
        self.callbacks.lock().unwrap().push(callb);
    }

    fn stop(&self) {
        let mut g = self.go.lock().unwrap();
        if *g {
            *g = false;
        }    
        self.notify_stream.lock().unwrap()
        .write(&to_bytevector(_PI_CMD_NC, self.handle, 0, 0));
    }

    fn remove(&self, callb: &_callback_ADT) {  
        let mut callbacks = self.callbacks.lock().unwrap();
        let index: usize;
        let mut newMonitor: u32 = 0;

        let r = callbacks.iter()
                    .position(|x| *x == *callb);
        if let Some(index) = r {
            callbacks.remove(index);
                      
            for c in callbacks.iter() {
                newMonitor |= c.bit;
            }
            let mut monitor = self.monitor.lock().unwrap();
            if newMonitor != *monitor {
                *monitor = newMonitor;
                _pigpio_command(&self.control_stream,
                                _PI_CMD_NB, self.handle,
                                *monitor);
            }
        }
    }
}

fn notification_thread(t: Arc<_callback_thread>) {
    let mut lastLevel = 0u32;
    let mut changed = 0u32;
    let mut newLevel:u32;
    let mut gpio = 0u32;
    let  (mut seq, mut flags, mut tick, mut level) =
         (0u16, 0u16, 0u32, 0u32);
    const MSG_SIZE:usize = 12;
    let mut recvd_data: [u8; MSG_SIZE] = [0;MSG_SIZE];


    lastLevel = _pigpio_command(& t.control_stream, 
                    _PI_CMD_BR1, 0, 0);     
    while *(t.go.lock().unwrap()) {

        let r = t.notify_stream.lock().unwrap()
                .read(&mut recvd_data[..]);
        let bytes_recvd = r.expect("fn run: socket read failed");
        if bytes_recvd != MSG_SIZE {
            panic!("fn run: too few bytes received");
        }

        if *(t.go.lock().unwrap()) {

            let (seq, flags, tick, level) = 
            unpack_data_in_callback_thread(&recvd_data[..]);

            if flags == 0 {
                changed = level ^ lastLevel;
                lastLevel = level;
                let callbacks = t.callbacks.lock().unwrap();
                for cb in &(*callbacks) {
                    if (cb.bit  & changed) != 0{
                        newLevel = 0;
                        if (cb.bit & level) != 0 {
                            newLevel = 1;
                        }
                        if (cb.edge ^ newLevel) != 0 {
                            (cb.func)(cb.gpio, newLevel, tick);
                        }
                    }
                }

            } else {
                if (flags as u32 & NTFY_FLAGS_WDOG) != 0 {
                    gpio = flags as u32 & NTFY_FLAGS_GPIO;
                    let callbacks = t.callbacks.lock().unwrap();
                    for cb in &(*callbacks) {
                        if cb.gpio == gpio {
                            (cb.func)(cb.gpio, TIMEOUT, tick);
                        }
                    }
                }
            }
           
        }

    }
}

fn _pigpio_command_send(stream: & Mutex<TcpStream>, 
                        data: &[u8]) -> u32 {
    let mut stream = stream.lock().unwrap();
    let r = stream.write(data);
    let bytes_written = r.expect("Write failed");
    if bytes_written != 16 {
        panic!("Write failed: did not write 16 bytes");
    }
    let mut recvd_data: [u8; 16] = [0; 16];
    let r = stream.read(&mut recvd_data[..]);
    let bytes_recvd = r.expect("Read failed");
    if bytes_recvd != 16 {
        panic!("Read failed: did not read 16 bytes");
    }
    to_u32(&recvd_data[12..16])
}

fn _pigpio_command(stream: & Mutex<TcpStream>, 
                   cmd: u32, p1: u32, p2: u32) -> u32 {
    let data = &to_bytevector(cmd, p1, p2, 0);
    _pigpio_command_send(stream, data)
}

fn _pigpio_command_ext(stream: &Mutex<TcpStream>,
                       cmd: u32, p1: u32, p2: u32,
                       p3: u32, extents: Vec<Vec<u8>>) -> u32 {
    let data = &to_bytevector_ext(cmd, p1, p2, p3, extents);
    _pigpio_command_send(stream, data)
}

impl Pi {
    fn new() -> Pi {
        let host = env::var("PIGPIO_ADDR")
                   .unwrap_or("localhost".to_string());
        let port = env::var("PIGPIO_PORT")
                   .unwrap_or("8888".to_string());
        let serv_addr = format!("{}:{}", host, port);
        let control_stream = TcpStream::connect(&*serv_addr).unwrap();
        let control_stream = Arc::new(Mutex::new(control_stream));
        let control_stream_cloned = control_stream.clone();
        Pi { 
            control_stream: control_stream, 
            _notify: _callback_thread
                    ::new(control_stream_cloned,
                          host, port),
        }

    }

    fn _rxbuf(&self, count: u32) -> Vec<u8> {
    
        let mut v:Vec<u8> = vec![];
        v.resize(count as usize, 0);

        let mut stream = self.control_stream.lock().unwrap();
        stream.read_exact(&mut v[..]).unwrap();

        v
    }

    fn set_mode(&self, gpio: u32, mode: u32) -> i32 {
        to_i32(_pigpio_command(&self.control_stream, 
                               _PI_CMD_MODES, gpio, mode))
    }

    fn get_mode(&self, gpio: u32) -> i32 {
        to_i32(_pigpio_command(&self.control_stream, 
                               _PI_CMD_MODEG, gpio, 0))
    }

    fn set_pull_up_down(&self, gpio: u32, pud: u32) -> i32 {
        to_i32(_pigpio_command(&self.control_stream, 
                               _PI_CMD_PUD, gpio, pud))
    }

    fn read(&self, gpio: u32) -> i32 {
        to_i32(_pigpio_command(&self.control_stream, 
                               _PI_CMD_READ, gpio, 0))
    }

    fn write(&self, gpio: u32, level: u32) -> i32 {
        to_i32(_pigpio_command(&self.control_stream, 
                               _PI_CMD_WRITE, gpio, level))
    }

    fn set_PWM_dutycycle(&self, user_gpio: u32, 
                         dutycycle: u32) -> i32 {
        to_i32(_pigpio_command(&self.control_stream,
                               _PI_CMD_PWM, user_gpio, 
                               dutycycle))
    }

    fn get_PWM_dutycycle(&self, user_gpio: u32) -> i32 {
        to_i32(_pigpio_command(&self.control_stream,
                               _PI_CMD_GDC, user_gpio, 0))
    }

    fn set_servo_pulsewidth(&self, user_gpio: u32, 
                            pulsewidth: u32) -> i32 {
        to_i32(_pigpio_command(&self.control_stream,
                               _PI_CMD_SERVO, user_gpio,
                               pulsewidth))
    }

    fn get_servo_pulsewidth(&self, 
                            user_gpio: u32) -> i32 {
        to_i32(_pigpio_command(&self.control_stream,
                               _PI_CMD_GPW, user_gpio, 0))

    }

    fn spi_open(&self, spi_channel: u32, baud: u32,
                spi_flags: u32) -> i32 {
        
        let mut v:Vec<u8> = vec![];        
        v.write_u32::<LittleEndian>(spi_flags).unwrap();
        
        to_i32(_pigpio_command_ext(&self.control_stream, _PI_CMD_SPIO,
                                   spi_channel, baud, 4, 
                                   vec![v]))   
    }

    fn spi_close(&self, handle: i32) -> i32 {
        
        to_i32(_pigpio_command(&self.control_stream, _PI_CMD_SPIC,
                               handle as u32, 0))
    }

    fn spi_read(&self, handle: u32, 
                count: u32) -> (u32, Vec<u8>) {

        let mut stream = self.control_stream.lock().unwrap();
        let data = &to_bytevector(_PI_CMD_SPIR,
                                  handle, count,
                                  0);
        let r = stream.write(data);
        let bytes_written = r.expect("Write failed");
        if bytes_written != 16 {
            panic!("Write failed: did not write 16 bytes");
        }
        let mut recvd_data: [u8; 16] = [0; 16];
        let r = stream.read(&mut recvd_data[..]);
        let bytes_recvd = r.expect("Read failed");
        if bytes_recvd != 16 {
            panic!("Read failed: did not read 16 bytes");
        }
                    
        let spi_read_data_len = to_u32(&recvd_data[12..16]);
        let spi_data:Vec<u8>;

        if to_i32(spi_read_data_len) > 0 {
            spi_data = self._rxbuf(spi_read_data_len);
        } else {
            spi_data = vec![];
        }
        (spi_read_data_len, spi_data)
    }
        
    fn spi_write(&self, handle: u32, data: Vec<u8>) -> i32 {

        to_i32(_pigpio_command_ext(
                &self.control_stream,
                _PI_CMD_SPIW,
                handle, 0, data.len() as u32,
                vec![data]
              ))

    }

    fn callback(&self, user_gpio: u32, edge: u32, 
                func: CallbackFn) -> _callback {
        _callback::new(self._notify.clone(), 
                       user_gpio, edge, func)
    } 

}

fn sleep_ms(ms: u64) {
    thread::sleep(Duration::from_millis(ms));
}

fn test_write() {
    let mut pi = Pi::new();
    pi.set_mode(18, OUTPUT);

    loop {
        println!("{}", pi.write(18, 1));
        sleep_ms(100);
        println!("{}", pi.write(18, 0));
        sleep_ms(100);
    }
}

fn test_read() {
    let mut pi = Pi::new();
    pi.set_mode(18, INPUT);
    pi.set_pull_up_down(18, PUD_UP);

    loop {
        println!("{}", pi.read(18));
        sleep_ms(100);
    }
}

fn cbf(gpio: u32, level: u32, tick: u32) {
    println!("handler called, gpio: {}, tick: {} ...", 
             gpio, tick);
}
 
fn test_callback() {
    let mut pi= Pi::new();
    pi.set_mode(18, INPUT);
    pi.set_pull_up_down(18, PUD_UP);
    let mut cb = pi.callback(18, FALLING_EDGE, cbf);
    
    loop {
        pi.set_pull_up_down(18, PUD_DOWN);
        sleep_ms(500);
        pi.set_pull_up_down(18, PUD_UP);
        sleep_ms(500);
    }
}

fn test_pwm() {
    let mut pi = Pi::new();
    pi.set_mode(18, OUTPUT);
    pi.set_PWM_dutycycle(18, 127);
}

fn pwm_up_down() {
    let mut pi = Pi::new();
    let mut pwm_val = 0;
    loop {
        while pwm_val < 256 {
            pi.set_PWM_dutycycle(18, pwm_val);
            pwm_val += 1;
            sleep_ms(5);
        }
        pwm_val = 255;
        while pwm_val > 0 {
            pi.set_PWM_dutycycle(18, pwm_val);
            pwm_val -= 1;
            sleep_ms(5);
        }
    }
}

fn main() {
   // test_callback();
   // test_write();
   // test_read();
   // test_pwm();

    pwm_up_down();
}
