fn main() {
    let x = true;
    let y:bool = false;

    if x {
        println!("hello");
    } else {
        println!("world");
    }
}
