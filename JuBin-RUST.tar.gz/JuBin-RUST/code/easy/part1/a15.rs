
fn fun(a: [u8;4]) {

    println!("{:?}", a);
}

fn main() {
    let p = [1,2,3,4];
    fun(p);
}

