fn main() {
    let x = true;
    let y:bool = false;

    let t = if x {
        10
    } else {
        20
    };

    println!("{}", t);
}
