
fn main() {
    let x:i32 = 0;
    let y:u32 = 0;
    let z:u8 = 0;
    let p:f64 = 1.1;
}
