
fn main() {
    let mut x = 0;
    x = x + 1;
}
