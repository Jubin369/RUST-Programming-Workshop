
fn main() {
    let mut a = [1,2,3,4];
    a[0] = 10;
    println!("{}", a.len());
    println!("{:?}", a);
}
