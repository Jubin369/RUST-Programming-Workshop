
fn main() {
    let a = [1,2,3];
    let t = a[3];
}
