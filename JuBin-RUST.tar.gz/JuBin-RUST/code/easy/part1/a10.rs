fn main() {
    let x = true;
    let y:bool = false;
}
