
fn main() {
    //type is inferred
    let x = 0;
    x = x + 1;
}
