
fn main() {
    let a = vec![1,2,3];
    let t = a[3];
}
