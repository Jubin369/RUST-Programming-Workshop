
fn main() {
    let mut s = String::new();
    s.push('a'); s.push('b');
    s.push('c'); s.push('d');

    println!("{}", s);

    println!("{}", s.len());
}
