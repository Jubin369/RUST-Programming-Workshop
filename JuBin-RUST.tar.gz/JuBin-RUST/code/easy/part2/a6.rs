
fn main() {
    let mut s = "hello".to_string();
    s.push_str(",world");
    println!("{}", s);
}
