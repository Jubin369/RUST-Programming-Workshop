
fn main() {
    let s = "hello";
    let p = s[0];
}   
