
fn main() {
    let s = "Hello,world!";
    println!("this is a string: {}", s);
}
