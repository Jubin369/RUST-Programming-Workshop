
fn main() {
    let s = "hello, world";
    let r = s.replace("hello", "good");

    println!("{}",r);
}
