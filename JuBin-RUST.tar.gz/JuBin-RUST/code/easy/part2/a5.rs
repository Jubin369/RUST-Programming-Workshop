
fn main() {
    let mut s = String::new();

    s.push_str("abcd");
    println!("{}", s);

    println!("{}", s.len());
}
