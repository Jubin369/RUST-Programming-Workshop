
fn main() {
    let s = "abcd".to_string();
    let r = s.into_bytes();

    println!("{:?}", r);
}
