
fn main(){
    let x = Some(10);
    let y:Option<i32> = None;
    let z = Some("hello");

    println!("{:?},{:?},{:?}",x, y, z);
}
