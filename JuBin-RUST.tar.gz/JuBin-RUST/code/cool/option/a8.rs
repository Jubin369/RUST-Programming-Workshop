
fn main() {
    let mut v = vec![1,2,3];
    let m = v.pop(); 
    
    println!("{:?}", m);
}
