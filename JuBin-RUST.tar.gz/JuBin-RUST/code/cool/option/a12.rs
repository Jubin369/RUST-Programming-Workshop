
fn main() {
    let mut v = vec![10];
    let m:Option<i32> = v.pop(); 
    let t = m.unwrap();
    println!("{}", t);
}
