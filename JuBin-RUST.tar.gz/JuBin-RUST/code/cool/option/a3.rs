#[derive(Debug)]
enum Maybe {
    Just(i32),
    Nothing,
}

fn checked_divide(a: i32, b: i32) -> Maybe{

    if b == 0 {
        Maybe::Nothing
    } else {
        Maybe::Just(a/b)
    }
}

fn main() {
    let p =checked_divide(3, 2); 
    println!("{:?}", p);
}
