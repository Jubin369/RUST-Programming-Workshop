
fn sqr(x: i32) -> i32 {
    x*x
}

fn main() {
    
    let a = (0..10);
    let b = a.map(sqr);

    for x in b {
        println!("{}", x);
    }
}
