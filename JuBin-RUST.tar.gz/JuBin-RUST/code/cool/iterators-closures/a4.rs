fn main() {
    
    let a = (0..10);
    let b = a.map(|x| x*x);

    for x in b {
        println!("{}", x);
    }
}
