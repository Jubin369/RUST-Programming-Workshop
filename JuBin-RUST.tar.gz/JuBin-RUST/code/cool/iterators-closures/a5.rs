fn main() {
    
    let a = (0..10);
    let b = a.filter(|x| x%2 == 0);

    for x in b {
        println!("{}", x);
    }
}
