fn main() {
    
    let a = (0..20);
    let b = a.filter(|x| x%2 == 0)
             .map(|x|  x*x)
             .take(5);

    println!("{:?}", b);

    for x in b {
        println!("{}", x);
    }
}
