
fn main() {
    let v = vec![1,2,3,4];
    

    for x in v {
        println!("{}", x);
    }
}
