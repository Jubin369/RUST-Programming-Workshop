
fn main() {
    
    let a = (0..10);
    let b = a.take(5);

    for x in b {
        println!("{}", x);
    }
}
