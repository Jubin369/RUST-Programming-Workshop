
fn main() {
    
    let a = (0..10);
    
    for x in a {
        println!("{}", x);
    }
}
