
fn main() {
    let v = vec![1,2,3,4];
    
    let r = v.map(|x| x*x);
}
