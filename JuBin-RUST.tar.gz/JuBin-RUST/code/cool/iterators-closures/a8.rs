
fn main() {
    let v = vec![1,2,3,4];
    
    let r = v.iter().map(|x| x*x);

    for x in r{
        println!("{}", x);
    }
}
