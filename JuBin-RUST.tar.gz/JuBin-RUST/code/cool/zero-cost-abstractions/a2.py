
N = 100000000

print reduce(lambda x,y:x+y, xrange(N))
