
N = 6

print reduce(lambda x,y:x+y, xrange(N))
