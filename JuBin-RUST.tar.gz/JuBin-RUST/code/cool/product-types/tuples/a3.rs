
fn main() {
    let  p = (1,2,3.0);
    // de-structuring let
    let (x, y, z) = p;
   
    println!("{}, {}, {}", x, y, z);

}
