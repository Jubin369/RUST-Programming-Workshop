
fn main() {
    let  p = (1,2,3.0);
    
    println!("{}, {}, {}", p.0, p.1, p.2);

}
