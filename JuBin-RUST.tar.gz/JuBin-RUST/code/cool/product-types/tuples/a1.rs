
fn main() {
    let p = (1,2,3.0);
    
    println!("{:?}", p);

}
