
def identity(x):
    return x

r = identity(10)
print r
r = identity(2.3)
print r
r = identity("hello")
print r

