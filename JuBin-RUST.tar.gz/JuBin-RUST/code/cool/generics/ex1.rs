
//implement "first"

fn main() {
    let pair1 = (1, 2.3);
    let pair2 = ("hello", 10);
    println!("{}, {}", first(pair1), first(pair2));
}
