
fn identity(x: i32) -> i32  {
    x
}

fn main() {
    println!("{}", identity(10));
    println!("{}", identity(2345));
}
    
