
//Model a simple 'elevator' as a FSM.
//Two floor's: Ground and First.
//A single button for control: it is either
//Up or Down.
//Function next_floor should return the next floor
//given current floor and button state.

#[derive(Debug)]
enum Floor {
    Ground,
    First,
}

enum Button {
    Up,
    Down,
}

fn main() {

    println!("{:?}", next_floor(Floor::Ground, Button::Up));

}
