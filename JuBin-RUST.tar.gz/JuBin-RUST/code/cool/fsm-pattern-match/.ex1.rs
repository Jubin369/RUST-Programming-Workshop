
//Model a finite state machine

#[derive(Debug)]
enum Floor {
    Ground,
    First,
}

enum Button {
    Up,
    Down,
}


fn next_floor(curr_floor: Floor, btn: Button) -> Floor {
    match (curr_floor, btn) {
        (Floor::Ground, Button::Up)   => Floor::First,
        (Floor::Ground, Button::Down) => Floor::Ground,
        (Floor::First, Button::Up)    => Floor::First,
        (Floor::First, Button::Down)  => Floor::Ground,
    }
}

fn main() {

    println!("{:?}", next_floor(Floor::Ground, Button::Up));

}
