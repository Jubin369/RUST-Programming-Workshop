
enum Color {
    Red,
    Green,
    Blue,
}

fn main() {
    let c = Color::Red;
}
