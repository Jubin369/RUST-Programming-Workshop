#include <iostream>

using namespace std;

class Shape {
    public:
    virtual double area(void) = 0;
};


class Circle:public Shape {
    double radius;
    public:
    Circle(double r){radius = r;}
    double area(void){return 3.14*radius*radius;}
};

class Square:public Shape {
    double side;
    public:
    Square(double x){side = x;} 
    double area(void){return side * side;}
};


int main()
{
    Circle s1(10);
    Square s2(5);

    Shape *s;

    s = &s2;
    cout << s->area() << endl;
}


