
fn main() {
    let x = 4;
    match x {
        1 => println!("one"),
        2 => println!("two"),
        3 => println!("three"),
        _ => println!("not one,two,three"),
    }
}
