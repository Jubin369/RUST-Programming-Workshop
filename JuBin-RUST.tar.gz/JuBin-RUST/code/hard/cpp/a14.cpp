#include <vector>
#include <iostream>

using namespace std;

int main()
{
    vector<int> v;

    for(int i = 0; i < 10; i++) {
        v.push_back(1);
        cout << "size = " << v.size() << 
        " capacity = " << v.capacity() << endl;
    }
} 
    
