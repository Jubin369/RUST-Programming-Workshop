int main()
{
    int a = 1, b = 2;

    return 0;
}

