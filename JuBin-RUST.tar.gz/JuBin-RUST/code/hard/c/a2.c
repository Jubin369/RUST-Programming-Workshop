int main()
{
    int a = 10;
    int *b;
    
    b = &a;
    *b = 20;
}

