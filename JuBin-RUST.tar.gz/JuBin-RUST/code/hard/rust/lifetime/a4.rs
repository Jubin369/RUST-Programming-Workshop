
fn fun(v: &Vec<i32>) -> &Vec<i32> {
    v
}

fn main() {
    let v2: &Vec<i32>;
    {
        let v1 = vec![1,2,3];
        v2 = &v1;
        println!("{:?}", v2);
    }
}
