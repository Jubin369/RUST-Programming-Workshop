
fn fun1() {
    let v = vec![1,2,3];
}

fn main() {
    fun1();
}
