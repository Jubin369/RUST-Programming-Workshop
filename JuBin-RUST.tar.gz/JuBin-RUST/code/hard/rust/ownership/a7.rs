
fn fun1(v: Vec<u32>) ->Vec<u32> {

    println!("{:?}", v);

    v
}

fn main() {
    let mut  v1 = vec![1,2,3];
    
    v1 = fun1(v1);

    println!("{}", v1[0]);

}
