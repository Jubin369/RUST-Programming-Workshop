
fn change(t1: &Vec<i32>) {
    t1[0] = 10;
}

fn main() {
    let mut v = vec![1,2,3];

    change(&v);
}
