
fn main() {
    let v = vec![1,2,3];

    let t1 = &v;
    let t2 = &v;

    println!("{}, {}, {}", t1[0], t2[0], v[0]);
}
