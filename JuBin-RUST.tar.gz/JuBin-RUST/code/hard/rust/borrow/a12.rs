
fn main() {
    let mut v = vec![1,2];
    
    let t1 = &mut v;
    let t2 = &v;

    println!("{:?}", t1);
}
