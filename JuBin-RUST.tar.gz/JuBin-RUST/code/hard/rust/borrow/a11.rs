
fn main() {
    let mut v = vec![1,2];
    
    let t1 = &mut v;
    t1[0] = 10;   
    println!("{:?}", t1);
}
