
fn main() {
    let mut v = vec![1,2];

    let t2 = &v[0];
    println!("{}", t2);   

}
