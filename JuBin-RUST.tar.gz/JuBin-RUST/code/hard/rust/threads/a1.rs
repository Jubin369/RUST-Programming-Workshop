
use std::thread;

fn foo() {
    loop {
        println!("foo...");
    }
}

fn main() {
    
    thread::spawn(foo);

    loop {
        println!("main...");
    }
}

