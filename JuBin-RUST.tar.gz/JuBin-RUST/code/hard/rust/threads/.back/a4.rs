
use std::rc::Rc;
use std::sync::Arc;

fn main() {
    let mut v = vec![1,2,3,4];

    let mut a1 = Arc::new(v);
    let mut a2 = a1.clone();

    a1.push(10);
    a2.push(20);

    println!("{:?}", a1);
}
