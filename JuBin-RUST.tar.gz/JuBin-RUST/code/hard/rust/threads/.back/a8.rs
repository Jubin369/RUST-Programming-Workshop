use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;


fn foo(data: Arc<Mutex<Vec<i32>>>) {

    loop {
        {
            let data_1 = data.lock().unwrap();
            for v in data_1.iter() {
                print!("{},", v);
            }
            println!("");
        }
        thread::sleep(Duration::from_millis(100));
    }

}

fn main() {

    let data = Arc::new(Mutex::new(vec![]));

    let data_ref1 = data.clone();
    thread::spawn(move || foo(data_ref1));


    for i in 0.. {
        {
            let mut data_1 = data.lock().unwrap();
            data_1.push(i);
        }
        thread::sleep(Duration::from_millis(100));

    }
}
