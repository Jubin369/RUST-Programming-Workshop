
use std::thread;

fn foo(v: &Vec<i32>) {
    println!("{:?}", v);
}

fn fun() {

}

fn main() {
    
    let v = vec![1,2,3,4];    

    thread::spawn(move || foo(&v));

    loop {
        //println!("{:?}", v);
    }
}

