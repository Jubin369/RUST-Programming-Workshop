
a = [10,20,30]

b = a

b.append(40)

print a

