
#circular reference

a = [1,2,3]
a.append(a)

