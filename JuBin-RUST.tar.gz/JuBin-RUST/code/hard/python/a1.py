
a = [1, 2, 3, 4, 5]

# do some stuff here ..

a = [10, 20, 30]




