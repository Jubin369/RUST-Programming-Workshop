

def create_list(n):
    first = [1]
    last = first
    while n != 0:
        last.append([1])
        last = last[-1]
        n -= 1
    return first

print create_list(3)
        
    
