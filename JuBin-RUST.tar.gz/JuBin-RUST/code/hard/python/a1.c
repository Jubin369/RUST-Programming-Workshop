#include <stdlib.h>

int main()
{
    char *p;

    p = malloc(10 * sizeof(char));

    /* do some stuff here */

    p = malloc(10 * sizeof(char)); // bug!

}
