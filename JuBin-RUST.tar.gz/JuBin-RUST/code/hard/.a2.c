
void fun2()
{
    int p = 1; 
    int q = 2;
}

int* fun1()
{
    int *p;
    int a[10];
    p = a;
    return p; // bug
}

main()
{
    int *q, t;
    *q = 10;
    fun2();
    t = *q;
}

